class GolfHoleData {
  final int hole;
  final int par;
  final int index;
  final int timeTaken;
  final List<int> scores; // This will hold the scores for A, B, C, D

  GolfHoleData({
    required this.hole,
    required this.par,
    required this.index,
    required this.timeTaken,
    required this.scores,
  });
}

class InRow {
  final String label;
  final List<int> scores; // For A, B, C, D

  InRow({
    required this.label,
    required this.scores,
  });
}
